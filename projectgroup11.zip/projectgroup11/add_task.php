<?php
// Database connection settings
$host = 'localhost';
$dbname = 'study_planner';
$username = 'root';
$password = ''; // Update if your MySQL has a password

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$subject = $_POST['subject'];
$task = $_POST['task'];
$due_date = $_POST['due_date'];

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO tasks (subject, task, due_date) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $subject, $task, $due_date);

// Execute
if ($stmt->execute()) {
    echo "✅ Task added successfully!";
} else {
    echo "❌ Error: " . $stmt->error;
}

// Close connection
$stmt->close();
$conn->close();
?>
